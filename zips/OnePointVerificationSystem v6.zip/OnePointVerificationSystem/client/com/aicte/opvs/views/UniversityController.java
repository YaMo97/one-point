package com.aicte.opvs.views;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTreeTableView;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.image.ImageView;

public class UniversityController {

    @FXML
    private JFXButton submit;

    @FXML
    private ComboBox<?> state;

    @FXML
    private JFXTreeTableView<?> tableview;

    @FXML
    private ImageView home;

    @FXML
    void handlestate(ActionEvent event) {

    }

    @FXML
    void handlesubmit(ActionEvent event) {

    }

}
