package com.aicte.opvs.helpers;

public class Password {
	
	public static String generatePassword() {
		
		// generate random password 
		return "pass123";
	}

}
