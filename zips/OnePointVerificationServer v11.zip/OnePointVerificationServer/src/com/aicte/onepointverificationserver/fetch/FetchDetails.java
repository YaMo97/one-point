package com.aicte.onepointverificationserver.fetch;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
//import org.json.JSONException;
import org.json.JSONObject;

import com.aicte.onepointverificationserver.databasemethods.AICTEQuery;
import com.aicte.onepointverificationserver.details.IndividualDetails;
import com.aicte.onepointverificationserver.methods.HttpPost;
import com.google.gson.Gson;

/**
 * Servlet implementation class FetchDetails
 */
@WebServlet("/FetchDetails")
public class FetchDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public static StringBuffer strBuff;
 
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FetchDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	/** 
	 * 	private static JSONObject merge(JSONObject... jsonObjects) throws JSONException {
	 *
	 * 		JSONObject jsonObject = new JSONObject();
	 *
	 * 		for(JSONObject temp : jsonObjects){
	 *			Iterator<String> keys = temp.keys();
	 *	    	while(keys.hasNext()){
	 *	    		String key = keys.next();
	 *	        	jsonObject.put(key, temp.get(key));
	 *	    	}
	 *
	 * 		}
	 * 		return jsonObject;
	 * 	}
	 */
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		// receive Login ID from user and category 
		strBuff = HttpPost.listenClient(request);
		String category = request.getHeader("Category");
		String str = new String("(FetchDetails doPost)failed");


		System.out.println();
		System.out.println("FetchDetails servlet");
		System.out.println(strBuff);
		// fetch details from respective databases according to category
		System.out.println("category:" + category);

		StringBuffer errCode=new StringBuffer("1");
		
		switch (category)
		{
		case "Student":
		{
			IndividualDetails individualDetails = new Gson().fromJson(strBuff.toString(), IndividualDetails.class);
			//****************************************************************** Fetch from database**************************************			
			// Fetch Login Details from database Student Login
			try{
				AICTEQuery<IndividualDetails> query1 = new AICTEQuery<>();
				
				JSONArray jsonArray1 = query1.execute("FSL", individualDetails);
				System.out.println("jsonArray1: " + jsonArray1.toString());
				
				if (!(jsonArray1.isNull(0))) {
//					str = new Gson().toJson(individualDetails);
//					JSONObject object1 = new JSONObject(str);
//					object1 = merge(object1, jsonArray1.getJSONObject(0));
//										
//					individualDetails.setStudentLoginDetails(object1);
					
//					individualDetails.setStudentLoginDetails(object1.getInt("sno"), object1.getString("student_id"), object1.getString("university_name"), object1.getString("college_name"),
//							object1.getString("full_name")	, object1.getString("email_id"), object1.getString("login_id"), object1.getString("password_hash"), object1.getString("aadhaar_status"), object1.getString("bank_status"), object1.getString("pan_status"));
//					
//					individualDetails = new Gson().fromJson(str, IndividualDetails.class);
					
					individualDetails.setStudentLoginDetails(jsonArray1.getJSONObject(0));
					
					AICTEQuery<IndividualDetails> query2 = new AICTEQuery<>();
					JSONArray jsonArray2 = query2.execute("FSC", individualDetails);
					System.out.println("jsonArray2: " + jsonArray2.toString());
					
					if (!(jsonArray2.isNull(0))) {
						
						JSONObject obj = jsonArray2.getJSONObject(0);
						
//						individualDetails.setCollegeDetails(obj);
						
						individualDetails.setStateName(obj.getString("state_name"));
						individualDetails.setDistrictName(obj.getString("district_name"));
						
						System.out.println(new Gson().toJson(individualDetails));

						AICTEQuery<IndividualDetails> query3 = new AICTEQuery<>();
						
						JSONArray jsonArray3 = query3.execute("FSA", individualDetails);
						System.out.println("jsonArray3: " + jsonArray3.toString());
	
						if (!(jsonArray3.isNull(0))) {
							
//							str = new Gson().toJson(individualDetails);
//							
//							JSONObject object2 = new JSONObject(str);
//							object2 = merge(object2, jsonArray3.getJSONObject(0));
//					
//							System.out.println("object2: "+ object2.toString());
							
//							individualDetails.setIndividualDetails(object2);
							
							System.out.println("Hooray!");
													
							individualDetails.setIndividualPersonalDetails(jsonArray3.getJSONObject(0));
							individualDetails.setIndividualStudentProfessionalDetails(jsonArray3.getJSONObject(0));
							individualDetails.setIndividualBankDetails(jsonArray3.getJSONObject(0));
												
							errCode = new StringBuffer("0");
						}
						else {
							errCode = new StringBuffer("1");
							System.out.println("studenterror not found in student"+errCode);
						}
					}
					else {

						errCode = new StringBuffer("1");
						System.out.println("studenterror not found in college"+errCode);
					}
				}
				else{
					errCode = new StringBuffer("1");
					System.out.println("studenterror"+errCode);
				}


				str = new Gson().toJson(individualDetails);
				System.out.println("Hooray!" + str);
				
			} catch(Exception e) {
				System.out.println(e);
			}
			
			break;
		}
		case "Faculty":
		{
			IndividualDetails individualDetails = new Gson().fromJson(strBuff.toString(), IndividualDetails.class);
			//****************************************************************** Fetch from database**************************************			
			// Fetch Login Details from database Student Login
			try {
				AICTEQuery<IndividualDetails> query1 = new AICTEQuery<>();
				
				JSONArray jsonArray1 = query1.execute("FFL", individualDetails);
				System.out.println("jsonArray1: " + jsonArray1.toString());
				
				if (!(jsonArray1.isNull(0))) {
					
					individualDetails.setFacultyLoginDetails(jsonArray1.getJSONObject(0));
					
					AICTEQuery<IndividualDetails> query2 = new AICTEQuery<>();
					JSONArray jsonArray2 = query2.execute("FFC", individualDetails);
					System.out.println("jsonArray2: " + jsonArray2.toString());
					
					if (!(jsonArray2.isNull(0))) {
						
						JSONObject obj = jsonArray2.getJSONObject(0);
						
						individualDetails.setStateName(obj.getString("state_name"));
						individualDetails.setDistrictName(obj.getString("district_name"));
						
						System.out.println(new Gson().toJson(individualDetails));

						AICTEQuery<IndividualDetails> query3 = new AICTEQuery<>();
						
						JSONArray jsonArray3 = query3.execute("FFA", individualDetails);
						System.out.println("jsonArray3: " + jsonArray3.toString());
	
						if (!(jsonArray3.isNull(0))) {

							System.out.println("Hooray!");
													
							individualDetails.setIndividualPersonalDetails(jsonArray3.getJSONObject(0));
							individualDetails.setIndividualFacultyProfessionalDetails(jsonArray3.getJSONObject(0));
							individualDetails.setIndividualBankDetails(jsonArray3.getJSONObject(0));
												
							errCode = new StringBuffer("0");
						}
						else{
							errCode = new StringBuffer("1");
							System.out.println("facultyerror not found in faculty"+errCode);
						}
					}
					else {

						errCode = new StringBuffer("1");
						System.out.println("facultyerror not found in college"+errCode);
					}
				}
				else{
					errCode = new StringBuffer("1");
					System.out.println("facultyerror"+errCode);
				}

				str = new Gson().toJson(individualDetails);
				System.out.println("Hooray!" + str);
				
			}catch(Exception e){System.out.println(e);}
			
			break;
		}
		
		default:
			errCode = new StringBuffer("1");
			System.out.println("defaulterror"+errCode);
		}
		
		// convert result to StringBuffer
		HttpPost.replyClient(response, errCode, new StringBuffer(str));
	}
}
