package com.aicte.onepointverificationserver.fetch;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;

import com.aicte.onepointverificationserver.databasemethods.AICTEQuery;
import com.aicte.onepointverificationserver.methods.HttpGet;
import com.google.gson.Gson;

/**
 * Servlet implementation class FetchCollege
 */
@WebServlet("/FetchCollege")
public class FetchCollege extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static StringBuffer strBuff, errCode;   

	private ArrayList<String> universityList, collegeList;   

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FetchCollege() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		System.out.println();
		System.out.println("FetchCollege servlet");
		
		String str = new String();
		universityList = null;
		collegeList = null;
		errCode=new StringBuffer("0");
		
		try {
			String state = request.getParameter("state");
			System.out.println("State = " + state);
			
			if (state != null) {
				String university = request.getParameter("university");
				System.out.println("University = " + university);
				
				if (university != null) {
					// fetch colleges from college table where state and university given
					// fetch Universities from college table where state given		
					
					AICTEQuery<String> query = new AICTEQuery<>();
					
					JSONArray jsonArray= query.execute("FC", university);
					System.out.println(jsonArray.toString());			
					
					int i = 0;
					collegeList = new ArrayList<String>();
					while (!(jsonArray.isNull(i)))
					{
						collegeList.add(jsonArray.getJSONObject(i).getString("college_name"));
						i++;
					}
					
					str = new Gson().toJson(collegeList);
					strBuff = new StringBuffer(str);
					System.out.println(strBuff+ "\n" + i);
					
					errCode = new StringBuffer("" + i);
					response.setHeader("ErrCode", errCode.toString());
					
					//replyClient(response, new StringBuffer("" + i), new StringBuffer(str));
				} 
				else 
				{
//					// fetch Universities from college table where state given		
					
					AICTEQuery<String> query = new AICTEQuery<>();
					
					JSONArray jsonArray= query.execute("FU", state);
					System.out.println(jsonArray.toString());	
					
					int i = 0;
					universityList = new ArrayList<String>();
					while (!(jsonArray.isNull(i)))
					{
						// System.out.println(i);
						universityList.add(jsonArray.getJSONObject(i).getString("university_name"));
						i++;
					}
					str = new Gson().toJson(universityList);
					strBuff = new StringBuffer(str);
					System.out.println(strBuff + "\n" + i);
					
					errCode = new StringBuffer("" + i);
					response.setHeader("ErrCode", errCode.toString());
					
					//replyClient(response, new StringBuffer(1), new StringBuffer(str));
				}
				
				System.out.println("state "+ state + " university " + university);
			}
			else 
			{
				// return error code;
				
				errCode = new StringBuffer("0");
				response.setHeader("ErrCode", errCode.toString());
				strBuff = new StringBuffer("No state found!");
				//replyClient(response, new StringBuffer("-1"), new StringBuffer("No state found!"));
			}
			
			System.out.println(strBuff + "\n" + errCode);
			HttpGet.replyClient(response, errCode, strBuff);
			
		} catch(Exception e) {System.out.println(e);}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
