package com.aicte.onepointverificationserver.databasemethods;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.json.JSONArray;
import org.json.JSONException;

import com.aicte.onepointverificationserver.details.*;

public class UIDAIQuery<T> {

	final String MySQLDriver = "com.mysql.jdbc.Driver";
	
	final String URL = "jdbc:mysql://";
	final String HOST = "localhost";
	final int PORT = 3308;
	final String USER = "user";
	final String PASS = "user";
	final String DATABASE = "uidai";
	
	Connection con;
	
	public UIDAIQuery() {
		try {
			// Register the Driver
			   Class.forName(MySQLDriver);
			  
			// Establish Connection
			   System.out.println(URL + HOST+":"+PORT+"/"+DATABASE+"?user=" + USER + "&password=" + PASS);
			   con = DriverManager.getConnection(URL + HOST + ":" + PORT + "/" + DATABASE + "?user=" + USER + "&password=" + PASS);
			
			} catch(Exception e) {
				System.out.println("AICTEQuery(): Caught: " + e);
			}		
	}
	
	public JSONArray execute(String opcode, T obj) 
		throws JSONException {
		
		JSONArray json = null;
		
		ResultSet rs = null;
		
		PreparedStatement preStmt = null;
		
		try {			
			preStmt = con.prepareStatement(SQLQuery.SQL.get(opcode));
			
			switch (opcode.charAt(0)) {
			case 'L':
				// For Login Details
				switch(opcode.charAt(1)) {
				case 'E':
					// Employee
					
					preStmt.setString(1, ((EmployeeDetails) obj).getLoginId());
					
					rs=preStmt.executeQuery();
					
					json = ResultSetConverter.convert(rs);
					break;
					
				case 'S':
					// Student
					
					preStmt.setString(1, ((IndividualDetails) obj).getLoginId());
					
					rs=preStmt.executeQuery();
					
					json = ResultSetConverter.convert(rs);
					break;
					
				case 'F':
					// Faculty
					preStmt.setString(1, ((IndividualDetails) obj).getLoginId());
					
					rs=preStmt.executeQuery();
					
					json = ResultSetConverter.convert(rs);
					break;
				
				default:
					System.out.println("Unhandled Login opcode");
				}
				break;
				
			case 'C':
				// For College
				break;
				
			case 'V':
				// For Verify
				
				switch(opcode.charAt(1)) {
				case 'A':
					// For Aadhaar
					preStmt.setString(1, ((IndividualDetails) obj).getAadhaarNumber());
					
					rs=preStmt.executeQuery();
					
					json = ResultSetConverter.convert(rs);
					break;
				
				default:
					System.out.println("Unhandled Login opcode");
				}
				break;
			default:
				System.out.println("Unhandled Query");
			}
			
		} catch(Exception e) {
			System.out.println("AICTEQuery: Caught: " + e);
		}
		
		return json;
	}
}
