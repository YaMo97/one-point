package com.aicte.onepointverificationserver.databasemethods;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.json.JSONArray;
import org.json.JSONException;

import com.aicte.onepointverificationserver.details.*;

public class AICTEQuery<T> {

	final String MySQLDriver = "com.mysql.jdbc.Driver";
	
	final String URL = "jdbc:mysql://";
	final String HOST = "localhost";
	final int PORT = 3307;
	final String USER = "user";
	final String PASS = "user";
	final String DATABASE = "aicte";
	
	Connection con;
	
	public AICTEQuery() {
		try {
			// Register the Driver
			   Class.forName(MySQLDriver);
			  
			// Establish Connection
			   System.out.println(URL + HOST+":"+PORT+"/"+DATABASE+"?user=" + USER + "&password=" + PASS);
			   con = DriverManager.getConnection(URL + HOST + ":" + PORT + "/" + DATABASE + "?user=" + USER + "&password=" + PASS);
			
			} catch(Exception e) {
				System.out.println("AICTEQuery(): Caught: " + e);
			}		
	}
	
	public JSONArray execute(String opcode, T obj) 
		throws JSONException {
		
		JSONArray json = null;
		
		ResultSet rs = null;
		
		PreparedStatement preStmt = null;
		
		try {			
			preStmt = con.prepareStatement(SQLQuery.SQL.get(opcode));
			
			switch (opcode.charAt(0)) {
			case 'L': 	// First
				// For Login Details
				switch(opcode.charAt(1)) {
				case 'E':	// Second
					// Employee
					
					preStmt.setString(1, ((EmployeeDetails) obj).getLoginId());
					
					rs=preStmt.executeQuery();
					
					json = ResultSetConverter.convert(rs);
					break;
					
				case 'S':	// Second
					// Student
					
					preStmt.setString(1, ((IndividualDetails) obj).getLoginId());
					
					rs=preStmt.executeQuery();
					
					json = ResultSetConverter.convert(rs);
					break;
					
				case 'F':	// Second
					// Faculty
					preStmt.setString(1, ((IndividualDetails) obj).getLoginId());
					
					rs=preStmt.executeQuery();
					
					json = ResultSetConverter.convert(rs);
					break;
				
				default:
					System.out.println("Unhandled Login opcode");
				}
				break;
				
			case 'C':	// First
				// For College
				break;
				
			case 'V':	// First
				// For Verify
				
				switch(opcode.charAt(1)) {
				case 'A':
					// For Aadhaar
					
					break;
				
				default:
					System.out.println("Unhandled Login opcode");
				}
				break;
				
				
			case 'F':	// First
				
				// For Fetching
				switch(opcode.charAt(1)) {
				case 'U':	// Second
					// University List
					
					preStmt.setString(1, ((String) obj));
					
					rs=preStmt.executeQuery();
					
					json = ResultSetConverter.convert(rs);
					break;
					
				case 'C':	// Second
					// College List
					
					preStmt.setString(1, ((String) obj));
					
					rs=preStmt.executeQuery();
					
					json = ResultSetConverter.convert(rs);
					break;
					
				case 'S':	// Second
					// Student Details
					
				case 'F':	// Second
					// Faculty Details
					
					switch(opcode.charAt(2)) {
					case 'L':	// Third
						// Student Login Details
						
						preStmt.setString(1, ((IndividualDetails) obj).getLoginId());
						
						rs=preStmt.executeQuery();
						
						json = ResultSetConverter.convert(rs);
						break;
						
					case 'C':	// Third
						// College Details
						
						preStmt.setString(1, ((IndividualDetails) obj).getUniversityName());
						preStmt.setString(2, ((IndividualDetails) obj).getCollegeName());
						
						rs=preStmt.executeQuery();
						
						json = ResultSetConverter.convert(rs);
						break;
						
					case 'A':	// Third
						// All Details
						preStmt.setString(1, ((IndividualDetails) obj).getUniversityName());
						preStmt.setString(2, ((IndividualDetails) obj).getCollegeName());
						
						if (opcode.charAt(1) == 'S')
							preStmt.setString(3, ((IndividualDetails) obj).getStudentId());
						else if (opcode.charAt(1) == 'F')
							preStmt.setString(3, ((IndividualDetails) obj).getFacultyId());
						
						rs=preStmt.executeQuery();
						
						System.out.println("Query: Hooray!");
						
						json = ResultSetConverter.convert(rs);
						break;
						
					default:	// Third
						System.out.println("Unhandled Third opcode");
						break;
					}
					break;
					
				default:	// Second
					System.out.println("Unhandled Second opcode");
					break;
				}
				break;
									
			default:	// First
				System.out.println("Unhandled First opcode");
				break;
			}
			
		} catch(Exception e) {
			System.out.println("AICTEQuery: Caught: " + e);
		}
		
		return json;
	}
}
