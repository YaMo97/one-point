package com.aicte.onepointverificationserver.databasemethods;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public abstract class SQLQuery {
	
	public static final Map <String, String> SQL;
	static {
		final Map <String, String> sql = new HashMap<>();
		
		sql.put("LE", "select password_hash from EMPLOYEE_LOGIN where login_id = ?");
		sql.put("LS", "select password_hash from STUDENT_LOGIN where login_id = ?");
		sql.put("LF", "select password_hash from FACULTY_LOGIN where login_id = ?");
		
		sql.put("VA", "select full_name from UID where aadhaar_number = ?");
		
		sql.put("FU", "SELECT DISTINCT university_name from COLLEGE where state_name = ? ");
		sql.put("FC", "SELECT DISTINCT college_name from COLLEGE where university_name = ? ");
		// sql.put("FS", "select * from student A, student_login B , college C where A.university_name = ? and A.college_name = ? and A.student_id = (select student_id from student_login where login_id = ?) and A.student_id = B.student_id and A.university_name = C.university_name and A.college_name = C.college_name");
		
		sql.put("FSL", "select * from STUDENT_LOGIN where login_id = ?");
		sql.put("FSC", "select state_name, district_name from COLLEGE where university_name = ? and college_name = ?");
		sql.put("FSA", "select * from STUDENT where university_name = ? and college_name = ? and student_id=?");
		
		sql.put("FFL", "select * from FACULTY_LOGIN where login_id = ?");
		sql.put("FFC", "select state_name, district_name from COLLEGE where university_name = ? and college_name = ?");
		sql.put("FFA", "select * from FACULTY where university_name = ? and college_name = ? and faculty_id= ?");
		
		SQL = Collections.unmodifiableMap(sql);
	}
}
