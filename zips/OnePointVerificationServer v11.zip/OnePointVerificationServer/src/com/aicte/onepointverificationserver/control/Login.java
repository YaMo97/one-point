package com.aicte.onepointverificationserver.control;

import java.io.*;

import org.json.JSONArray;
import org.json.JSONObject;
//import org.json.JSONException;

import com.aicte.onepointverificationserver.databasemethods.AICTEQuery;
import com.aicte.onepointverificationserver.details.EmployeeDetails;
import com.aicte.onepointverificationserver.details.IndividualDetails;
import com.aicte.onepointverificationserver.methods.HttpPost;
//import java.util.StringTokenizer;
import com.google.gson.Gson;


import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;


	private static StringBuffer strBuff, replyBuff;
	
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		System.out.println("Login servlet");

		strBuff = HttpPost.listenClient(request);
		System.out.println(strBuff);
		replyBuff = new StringBuffer("failed");


		String category = request.getHeader("Category");
		System.out.println("category" + category);

		StringBuffer errCode=new StringBuffer("1");


		System.out.println(strBuff);

		switch (category){
		// Login Employee
		case "Employee":	
			EmployeeDetails rcvdEmployeeDetails = new Gson().fromJson(strBuff.toString(), EmployeeDetails.class);
			//****************************************************************** Fetch from database**************************************			
			// Fetch Login Details from database Employee Login
			
			try{
				AICTEQuery<EmployeeDetails> query = new AICTEQuery<>();
				
				JSONArray jsonArray= query.execute("LE", rcvdEmployeeDetails);
				//System.out.println(jsonArray.toString());
				
				if (!(jsonArray.isNull(0))) {
					// Compare receivedPasswordHash with passwordHash(fetched from database)
					
					JSONObject employeeJSON = jsonArray.getJSONObject(0); 
					System.out.println(employeeJSON.get("password_hash"));
					
					if (employeeJSON.get("password_hash").equals(rcvdEmployeeDetails.getPasswordHash())) {
						// return true
						errCode = new StringBuffer("0");
						replyBuff = new StringBuffer("success");
					}
					else {
						// else return error code 1 (login/id password incorrect)
						errCode = new StringBuffer("1");
					}
				}
				else {
					// Employee Doesn't Exist
					errCode = new StringBuffer("2");
					System.out.println("errCode: "+errCode);
					
					replyBuff = new StringBuffer("Employee Doesn't Exist!");
					System.out.println("replyBuff: " + replyBuff);
				}

			}catch(Exception e){System.out.println(e);}
			break;

			// Login Student
		case "Student": {

			IndividualDetails individualDetails = new Gson().fromJson(strBuff.toString(), IndividualDetails.class);
			//****************************************************************** Fetch from database**************************************			
			// Fetch Login Details from database Student Login
			
			try {
					AICTEQuery<IndividualDetails> query = new AICTEQuery<>();
					
					JSONArray jsonArray= query.execute("LS", individualDetails);
					System.out.println(jsonArray.toString());
					
					if (!(jsonArray.isNull(0))) {
						// Compare receivedPasswordHash with passwordHash(fetched from database)
						
						JSONObject individualJSON = jsonArray.getJSONObject(0); 
						System.out.println(individualJSON.get("password_hash"));
						
						if (individualJSON.get("password_hash").equals(individualDetails.getPasswordHash())) {
							// return true
							errCode = new StringBuffer("0");
							replyBuff = new StringBuffer("success");
						}
					else {
						// else return error code 1 (login/id password incorrect)
						errCode = new StringBuffer("1");
					}
				}
				else{
					errCode = new StringBuffer("2");
					System.out.println("errCode: "+errCode);
					
					replyBuff = new StringBuffer("Student Doesn't Exist!");
					System.out.println("replyBuff: " + replyBuff);
				}

			}catch(Exception e){System.out.println(e);}
			break;
		}

		// Login Faculty
		case "Faculty": {

			IndividualDetails individualDetails = new Gson().fromJson(strBuff.toString(), IndividualDetails.class);
			//****************************************************************** Fetch from database**************************************			
			// Fetch Login Details from database Faculty Login
			try {
				AICTEQuery<IndividualDetails> query = new AICTEQuery<>();
				
				JSONArray jsonArray= query.execute("LF", individualDetails);
				System.out.println(jsonArray.toString());
				
				if (!(jsonArray.isNull(0))) {
					// Compare receivedPasswordHash with passwordHash(fetched from database)
					
					JSONObject individualJSON = jsonArray.getJSONObject(0); 
					System.out.println(individualJSON.get("password_hash"));
					
					if (individualJSON.get("password_hash").equals(individualDetails.getPasswordHash())) {
						// return true
						errCode = new StringBuffer("0");
						replyBuff = new StringBuffer("success");
					}
					else {
						// else return error code 1 (login/id password incorrect)
						errCode = new StringBuffer("1");
					}
				}
				else{
					errCode = new StringBuffer("2");
					System.out.println("errCode: "+errCode);
					
					replyBuff = new StringBuffer("Faculty Doesn't Exist!");
					System.out.println("replyBuff: " + replyBuff);
				}

			}catch(Exception e){System.out.println(e);}

			break;
		}

		default:
			errCode = new StringBuffer("1");

		}
		//****************************************************************** Send the response**************************************					
		//reply the client

		HttpPost.replyClient(response, errCode, replyBuff);
	}

}