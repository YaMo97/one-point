package com.aicte.onepointverificationserver.control;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.aicte.onepointverificationserver.databasemethods.DatabaseConnections;
import com.aicte.onepointverificationserver.details.IndividualDetails;
import com.google.gson.Gson;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	public static StringBuffer strBuff;
	public static StringBuffer errCode;
	private DatabaseConnections databaseConnections;
	private PreparedStatement preparedStatement,preparedStatement1,preparedStatement2;
	//private Statement statement;
	private Connection con;
	private ResultSet rs,rs1;  
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    private static StringBuffer listenClient(HttpServletRequest request) {
    	
    	try {	
			ServletInputStream is = request.getInputStream();
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
		
			String line;
	        strBuff = new StringBuffer(); 
			
			//Reading from the stream
	        while((line = br.readLine()) != null) {
	            
	                strBuff.append(line);
	        }
	        
	        br.close();
		} catch(Exception e) {
            System.out.println(e);
        }
		
		return strBuff;
    }
    
    private static void replyClient(HttpServletResponse response, StringBuffer errCode, StringBuffer strBuff){

		try{
			response.setHeader("ErrCode", errCode.toString());
			ServletOutputStream sos=response.getOutputStream();
			
			// success code
			sos.print(strBuff.toString());
			sos.close();


		} catch(Exception e) {System.out.println(e);}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		strBuff = listenClient(request);
		System.out.println();
		System.out.println("Register servlet");
		System.out.println(strBuff);
		
		
		// Break strBuff and store into object
		
		IndividualDetails individualDetails = new Gson().fromJson(strBuff.toString(), IndividualDetails.class);
		
		
		// Select Database according to profession/category/opcode
		String category = request.getHeader("Category");
		try {
			databaseConnections=new DatabaseConnections(3307);
			con=databaseConnections.getConnection();
			
			preparedStatement=con.prepareStatement("select email_id from " + category + "_LOGIN where email_id = ?");
			preparedStatement.setString(1, individualDetails.getEmailId());
			//statement=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			rs=preparedStatement.executeQuery();
			preparedStatement1=con.prepareStatement("select login_id from " + category + "_LOGIN where login_id = ?");
			preparedStatement.setString(1, individualDetails.getLoginId());
			
			// check if the user is already registered
			
			if(rs.next())
			{
				errCode = new StringBuffer("1");
			}
			else {
				rs1=preparedStatement1.executeQuery();
				
				if(rs1.next())
				{
					errCode = new StringBuffer("1");
				}
				
			}
			// if no
			errCode = new StringBuffer("1"); // DEBUG
			// Update the database using strBuff
			
			preparedStatement2=con.prepareStatement("INSERT INTO " + category + "_LOGIN (?_id, university_name, college_name, full_name, email_id, login_id, password_hash) VALUES (?, ?, ?, ?, ?, ?, ?)");
			if (category.equals("Student")){
				preparedStatement2.setString(1, "student");
				preparedStatement2.setString(2, "student");
			}	else {
			// if (category.equals("Faculty")) {
				preparedStatement2.setString(1, "faculty");
				preparedStatement2.setString(2, "faculty");
			}
			preparedStatement2.setString(3, individualDetails.getUniversityName());
			preparedStatement2.setString(4, individualDetails.getCollegeName());
			preparedStatement2.setString(5, individualDetails.getFullName());
			preparedStatement2.setString(6, individualDetails.getEmailId());
			preparedStatement2.setString(7, individualDetails.getLoginId());
			
			// generate password randomly 
			individualDetails.setPasswordHash("password");
			// 
			preparedStatement2.setString(8, individualDetails.getPasswordHash());
			
			int n = preparedStatement.executeUpdate();
			
			System.out.println("No of entries updated" + n);
			// set errCode = 0 on success
			// else set errCode = 1 
			
			errCode = new StringBuffer("0"); // DEBUG
		}catch(Exception e){System.out.println(e);}
			
		replyClient(response, errCode, new StringBuffer(""));
	}

}
