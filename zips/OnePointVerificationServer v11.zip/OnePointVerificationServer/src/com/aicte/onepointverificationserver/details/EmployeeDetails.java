package com.aicte.onepointverificationserver.details;

import org.json.JSONObject;

public class EmployeeDetails {
    
    protected int employeeSno;
    protected String employeeId;
    protected String employeeName;
    protected String emailId;
    protected String loginId;
    protected String passwordHash;
    
    // Constructor
    public EmployeeDetails() {
        employeeSno = -1;
        employeeId = null;
        employeeName = null;
        emailId = null;
        loginId = null;
        passwordHash = null;
    }
    
    public int getEmployeeSno() {
        return employeeSno;
    }
    
    public String getEmployeeId() {
        return employeeId;
    }
    
    public String getEmployeeName() {
        return employeeName;
    }
    
    public String getEmailId() {
        return emailId;
    }
    
    public String getLoginId() {
        return loginId;
    }
    
    public String getPasswordHash() {
        return passwordHash;
    }
    
    public void setEmployeeSno(int x) {
        employeeSno = x;
    }
    
    public void setEmployeeId(String x) {
        employeeId = x;
    }
    
    public void setEmployeeName(String x) {
        employeeName = x;
    }
    
    public void setEmailId(String x) {
        emailId = x;
    }
    
    public void setLoginId(String x) {
        loginId = x;
    }
    
    public void setPasswordHash(String x) {
        passwordHash = x;
    }
    
    public void setEmployeeDetails(int a, String b, String c, String d, String e, String f) {
    	
        employeeSno = a;
        employeeId = b;
        employeeName = c;
        emailId = d;
        loginId = e;
        passwordHash = f;
    }
    
    public void setEmployeeDetails(JSONObject obj) {
    	employeeSno		= obj.getInt("sno");
    	employeeId 		= obj.getString("employee_id"); 
    	employeeName 	= obj.getString("employee_name");
    	emailId 		= obj.getString("email_id"); 
    	loginId 		= obj.getString("login_id"); 
    	passwordHash 	= obj.getString("password_hash");	
    }
    
}

