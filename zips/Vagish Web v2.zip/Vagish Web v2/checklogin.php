<?php


$data=json_decode(file_get_contents("php://input"));
$id=$data->email;
$pass=$data->pass;
$server="localhost";
$username="root";
$password="";
$db="test";
$conn=new mysqli($server,$username,$password,$db);
if($conn->connect_error){
	die($conn->connect_error);
}

$sql="SELECT PASS FROM CREDENTIALS WHERE EMAIL_ID='$id'";
$result=$conn->query($sql);
if($result->num_rows>0){
$row=$result->fetch_assoc();
if($pass==$row['PASS']){
		echo $row['PASS'];
		
}
else{
	echo 1;
}
}
else{
		echo 2;
		
}

$conn->close();
?>