<?php
$data=json_decode(file_get_contents("php://input"));
$name=$data->name;
$email=$data->email;
$aadhar=$data->aadhar;
$father=$data->father;
$mother=$data->mother;
$nationality=$data->nationality;
$marital=$data->marital;
$dob=$data->dob;
$gender=$data->gender;
$mobile=$data->mobile;
$telephone=$data->telephone;
$address=$data->address;
$correspondence=$data->correspondence;
$pan=$data->pan;
$bankname=$data->bankname;
$branchname=$data->branchname;
$account=$data->account;
$ifsc=$data->ifsc;
$micr=$data->micr;

$servername="localhost";
$username="root";
$password="";
$db="test";

$conn=new mysqli($servername,$username,$password,$db);
if($conn->connect_error){
	die("error...");
}

$sql="CREATE TABLE STUDENTS(
	STUDENT_ID INTEGER(15) PRIMARY KEY, 
	UNIV_ID INTEGER(10),
	COLLEGE_ID INTEGER(10),
	FULL_NAME VARCHAR(15),
	EMAIL VARCHAR(15),
	AADHAR_NO INTEGER(16),
	FATHERS_NAME VARCHAR(15),
	MOTHERS_NAME VARCHAR(15),
	DOB DATE,
	GENDER VARCHAR(1),
	MARITAL_STATUS VARCHAR(7),
	NATIONALITY VARCHAR(10),
	CORRESPONDENCE_ADDRESS VARCHAR(25),
	PERMANENT_ADDRESS VARCHAR(25),
	MOBILE_NO INTEGER(10),
	TELEPHONE_NO INTEGER(11),
	COURSE VARCHAR(5),
	BRANCH VARCHAR(5),
	START_DATE DATE,
	EXPECTED_END_DATE DATE,
  	PAN_NO INTEGER(15),
  	BANK_NAME VARCHAR(10),
  	BANK_BRANCH VARCHAR(10),
  	ACCOUNT_NO INTEGER(15),
  	IFSC VARCHAR(10),
  	MICR INTEGER(10)
	

	)";

$conn->query($sql);

$sql="INSERT INTO STUDENTS(FULL_NAME,EMAIL,AADHAR_NO,FATHERS_NAME,MOTHERS_NAME,MARITAL_STATUS,NATIONALITY,DOB,GENDER,
		CORRESPONDENCE_ADDRESS,PERMANENT_ADDRESS,MOBILE_NO,TELEPHONE_NO,PAN_NO,BANK_NAME,BANK_BRANCH,ACCOUNT_NO,IFSC,MICR)
		VALUES('$name','$email','$aadhar','$father','$mother','$marital','$nationality','$dob','$gender','$correspondence',
			'$address','$mobile','$telephone','$pan','$bankname','$branchname','$account','$ifsc','$micr')";

$conn->query($sql);

echo "updated(1)";
$conn->close();



?>