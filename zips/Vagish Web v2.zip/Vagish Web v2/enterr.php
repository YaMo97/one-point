
<?php

$data=json_decode(file_get_contents("php://input"));
$name=$data->name;
$email=$data->id;
$password=$data->pass;
$user="root";
$servername="localhost";
$passw="";
$database="test";
$conn=new mysqli($servername,$user,$passw,$database);
if($conn->connect_error){
	die("Error Connecting...");
}
$sql="INSERT INTO CREDENTIALS(NAME,EMAIL_ID,PASS)
	VALUES('$name','$email','$password')";
if($conn->query($sql)===TRUE){
	echo "New record created";

}
else{
	echo "error ".$conn->error;
}
$conn->close();
?>