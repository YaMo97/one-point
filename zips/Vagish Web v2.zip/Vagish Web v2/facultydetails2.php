<?php
$data=json_decode(file_get_contents("php://input"));
$facultyid=$data->id;
$college=$data->college;
$university=$data->university;
$department=$data->department;
$doj=$data->doj;
$specialisation=$data->specialisation;
$designation=$data->designation;
$appointment=$data->appointment;
$email=$data->email;

$server="localhost";
$user="root";
$password="";
$db="test";
$conn=new mysqli($server,$user,$password,$db);

if($conn->connect_error){
	die("error connecting..");
}

$sql="UPDATE FACULTY SET FACULTY_ID='$facultyid',COLLEGE_ID='$college',UNIV_ID='$university',DEPARTMENT='$department',
		DESIGNATION='$designation',SPECIALISATION='$specialisation',DOJ='$doj',APPOINTMENT='$appointment' WHERE EMAIL='$email'";

if($conn->query($sql)===TRUE){
	echo "updated(2)";
}
else
	echo "error";


$conn->close();
?>
