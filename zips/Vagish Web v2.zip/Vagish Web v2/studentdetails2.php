<?php

$data=json_decode(file_get_contents("php://input"));
$studentid=$data->studentid;
$college=$data->college;
$university=$data->university;
$branch=$data->branch;
$course=$data->course;
$start=$data->start;
$end=$data->end;
$email=$data->email;

$server="localhost";
$user="root";
$password="";
$db="test";
$conn=new mysqli($server,$user,$password,$db);

if($conn->connect_error){
	die("error connecting..");
}

$sql="UPDATE STUDENTS SET STUDENT_ID='$studentid',COLLEGE_ID='$college',UNIV_ID='$university',COURSE='$course',
			BRANCH='$branch',START_DATE='$start',EXPECTED_END_DATE='$end' WHERE EMAIL='$email'";

$conn->query($sql);

echo "updated(2)";

$conn->close();
?>
