/*
myController controller
Vagish Yaduvanshi
*/
/*app.factory("Fact",function(){
	return {
		email=''
	}	
		
 
});
*/
app.controller("loginController",function($scope,$location,$http){
	$scope.login={};
	var x,y,r;
	if(!$scope.login.email){
		x=0;
		$scope.login.FillEmail=1;
		}
	else{
			x=1;
			$scope.login.FillEmail=0;
		}
	if(!$scope.login.pass){
		y=0;
		$scope.login.FillPass=1;
	}
	else{
		y=1;
		$scope.login.FillPass=0;
	}
	
$scope.check=function(){
	var x,y,r;
	if(!$scope.login.email){
		x=0;
		
		}
	else{
			x=1;
		}
	if(!$scope.login.pass){
		y=0;
		
	}
	else{
		y=1;
	}

	r=x*y;
	if(r)
	{	
	var config={
		headers:{
				'Content-Type':'application/json;charset=UTF-8'
			}
		};
		var dat={
			email:$scope.login.email,
			pass:$scope.login.pass
		};
		$http.post("checklogin.php",dat,config)
		.success(function(data){
			if($scope.login.pass===data){
				console.log("true");
				$location.path('/personal').search('key',$scope.login.email);
			}
			else{
				
				if(data==1)
					console.log("no match");
					$scope.login.InvalidCredentials=1;
				if(data==2)
					console.log("record not found");
					$scope.login.NotRegistered=1;
			}


		})
		.error(function(status){
			console.log(status);
		});
	}
	else{
			console.log("fill fields");
		}
	};

	
});

app.controller("myController",function($scope,$http,$location){
	$scope.registerdetails={};
	$scope.checkFields=function(){
		var x,y,z,m,o,r;
		if(!$scope.registerdetails.fname){
			x=0;

		}else{
			x=1;
		}
		if(!$scope.registerdetails.email){
			y=0;
		}
		else{
			y=1;
		}
		if($scope.registerdetails.password!==$scope.registerdetails.confirm){
			o=0;
		}
		else{
			o=1;
		}
		if(!$scope.registerdetails.confirm){
			z=0;
		}
		else{
			z=1;
		}
		if(!$scope.registerdetails.confirm){
			m=0;
		}
		else{
			m=1;
		}
		r=x*y*z*o*m;
		

		if(r){
			return true
		}
		else{
			return false
		}
	}
	
	$scope.registerButton=function(){	

			var dat={
				name:$scope.registerdetails.fname,
				id:$scope.registerdetails.email,
				pass:$scope.registerdetails.password
			};
			var config={
				headers:{
					'Content-Type':'application/json;charset=UTF-8'
				}
			};
			
			$http.post("enterr.php",dat,config)
			.then(function(data,status,headers,config){
				
					$location.path('/personal').search('key',$scope.registerdetails.email);
	
				
				
			}
			,function(data,status,headers,config){
				console.log(status);

					
			});
			
		
			
	};
	

	});


app.controller("perController",function($scope,$location,$http){
	var common=$location.search();
	$scope.per={};
	$scope.temp={};
	$scope.per.email=common.key;
	var config={
				headers:{
					'Content-Type':'application/json;charset=UTF-8'
				}
			};
	var dat={
		email:$scope.per.email

	};
	
	$http.post("recieve.php",dat,config)
	.success(function(data){
		$scope.per.fname=data;
		console.log(data);	
	})
	.error(function(data,status,config,headers)
		{
			console.log("error");

		});
	$scope.faculty=function(){
	var da={
		name:$scope.per.fname,
		email:$scope.per.email,
		aadhar:$scope.per.aadhar,
		father:$scope.per.father,
		mother:$scope.per.mother,
		nationality:$scope.per.nationality,
		marital:$scope.per.marital,
		dob:$scope.per.dob,
		gender:$scope.per.gender,
		mobile:$scope.per.mobile,
		telephone:$scope.per.telephone,
		address:$scope.per.address,
		correspondence:$scope.per.correspondence,
		pan:$scope.per.pan,
		bankname:$scope.per.bankname,
		branchname:$scope.per.branchname,
		account:$scope.per.account,
		ifsc:$scope.per.ifsc,
		micr:$scope.per.micr

	};
	var confi={
				headers:{
					'Content-Type':'application/json;charset=UTF-8'
				}
			};
	$http.post("facultydetails1.php",da,confi)
		.success(function(data){
			$location.path('/faculty').search('key',$scope.per.email);
			console.log(data);	
		})
		.error(function(status){
			console.log(status);
		});
	};
	$scope.student=function(){
	var da={
		name:$scope.per.fname,
		email:$scope.per.email,
		aadhar:$scope.per.aadhar,
		father:$scope.per.father,
		mother:$scope.per.mother,
		nationality:$scope.per.nationality,
		marital:$scope.per.marital,
		dob:$scope.per.dob,
		gender:$scope.per.gender,
		mobile:$scope.per.mobile,
		telephone:$scope.per.telephone,
		address:$scope.per.address,
		correspondence:$scope.per.correspondence,
		pan:$scope.per.pan,
		bankname:$scope.per.bankname,
		branchname:$scope.per.branchname,
		account:$scope.per.account,
		ifsc:$scope.per.ifsc,
		micr:$scope.per.micr

	};
	var confi={
				headers:{
					'Content-Type':'application/json;charset=UTF-8'
				}
			};
	
		$http.post("studentdetails1.php",da,config)
		.success(function(data){
			$location.path('/student').search('key',$scope.per.email);
			console.log(data);	
		})
		.error(function(status){
			console.log(status);
		});
		
	};
});



app.controller("facultyController",function($scope,$http,$location){
		$scope.faculty={};

		
		var common=$location.search();
		$scope.faculty.email=common.key;
		var dat={
			email:$scope.faculty.email
		};
		var config={
			headers:{
					'Content-Type':'application/json;charset=UTF-8'
			}
		};
		
		$http.post("recieve.php",dat,config)
		.success(function(data){
				$scope.faculty.fname=data;

		})
		.error(function(status){
				console.log(status);
		});
		$scope.register=function(){
		var config={
			headers:{
					'Content-Type':'application/json;charset=UTF-8'
			}
		};
		var da={
			id:$scope.faculty.facultyid,
			university:$scope.faculty.universityid,
			college:$scope.faculty.collegeid,
			department:$scope.faculty.department,
			doj:$scope.faculty.doj,
			specialisation:$scope.faculty.specialisation,
			designation:$scope.faculty.designation,
			appointment:$scope.faculty.appointment,
			email:$scope.faculty.email

		};
			$http.post("facultydetails2.php",da,config)
			.success(function(data){
				$location.path('/').search('key',null);
				console.log(data);
				window.alert("Infromation Updated");


			})
			.error(function(status){
				console.log(status);
			});
			
		};

});

app.controller("studentController",function($scope,$http,$location){
		
		$scope.student={};
		var common=$location.search();
		
		
		$scope.student.email=common.key;
		var dat={
			email:$scope.student.email
		};
		
		var config={
			headers:{
					'Content-Type':'application/json;charset=UTF-8'
			}
		};
		$http.post("recieve.php",dat,config)
		.success(function(data){
				$scope.student.fname=data;

		})
		.error(function(status){
				console.log(status);
		});
		$scope.register=function(){
		var da={
			studentid:$scope.student.studentid,
			college:$scope.student.collegeid,
			university:$scope.student.universityid,
			branch:$scope.student.branch,
			course:$scope.student.course,
			start:$scope.student.startdate,
			end:$scope.student.enddate,
			email:$scope.student.email

		};
		var config={
			headers:{
					'Content-Type':'application/json;charset=UTF-8'
			}
		};
			$http.post("studentdetails2.php",da,config)
			.success(function(data){
				$location.path('/').search('key',null);
				console.log(data);
				window.alert("Infromation Updated");


			})
			.error(function(status){
				console.log(status);
			});
		};

});


