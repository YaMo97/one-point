/*
myApp module
Vagish Yaduvanshi
*/
var app=angular.module("myApp",['ngRoute'])
app.config(['$routeProvider',function($routeProvider){
		$routeProvider
		.when('/register',{

			templateUrl:'Register.html'
			
		})
		.when('/login',{

			templateUrl:'login.html'
			
		})
		.when('/personal',{
			templateUrl:'personal_details.html'
		})
		.when('/faculty',{
			templateUrl:'faculty.html'
		})
		.when('/student',{
			templateUrl:'student.html'
		});
		
		}

]);