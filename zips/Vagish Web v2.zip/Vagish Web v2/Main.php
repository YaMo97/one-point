<!--
Main
Vagish Yaduvanshi
-->
<!DOCtype html>
<html>
<head>

	<link rel="stylesheet" href="assets/demo.css">
	<link rel="stylesheet" href="assets/form-login.css">
	<link rel="stylesheet" href="assets/other.css">

	<link rel="stylesheet" href="assets/form-register.css">
	<title>One Point Verification System</title>
	<meta charset="UTF-8"/>
	<meta name="viewport" cotent="width=device-width, initial-scale=1"/>
	<link rel="stylesheet" href="bootstrap-3.3.7-dist\css\bootstrap.min.css">
</head>
<body >
	<script type="text/javascript" src="angular_js\angular.min.js">
	</script>
	<script type="text/javascript" src="angular_js\route.min.js">
	</script>
	<script src="jquery\jquery.js">
	</script>	
	<script src="bootstrap-3.3.7-dist\js\bootstrap.min.js">
	</script>
	
	<script src="myApp.js"></script>
	<script src="myController.js"></script>
	<div ng-app="myApp">
	<div class="row" style="background:rgb(30,41,51)">
		<div class="col-sm-12" style="color:rgb(66,74,81);margin:10px">
		<?php print "<b><h4>".date("Y m,d h:m:sa")."</h4></b>";
		?>
	</div>
	</div>
		<header>
		<h1><b>All India Council of Technical Education</b></h1>
	
		<br>	
		<div class="row">
		<div class="col col-sm-7">
			
		</div>
		<div class="col col-sm-5">
			<img src="new picture.png">
		</div>
		
	</div>	
        <a href="#/" link="rgb(255,218,98)"><h>
        
		Education Councils & Boards Office<br> Jawaharlal Nehru University
		<br/>
		1, Nelson Mandela Marg, Jawaharlal Nehru University,<br> New Delhi, Delhi
		</h5>
	</a>
	
    </header>

    <ul>
       
        <li><a href="#/register" >Register</a></li>
        <li><a href="#/login">Login</a></li>
        
    </ul>

		<div class="jumbotron">
			<div class="row">
			<div class="col-sm-2">
			</div>
			<div class="col-sm-10" ng-view>

			</div>
			</div>
		</div>
	</div>
	
	
</body>
</html>
