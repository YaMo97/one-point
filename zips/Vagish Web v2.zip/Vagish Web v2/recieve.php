<?php
$data=json_decode(file_get_contents("php://input"));
$server="localhost";
$username="root";
$password="";
$db="test";
$conn=new mysqli($server,$username,$password,$db);
if($conn->connect_error){
	die($conn->connect_error);
}
$key=$data->email;
$sql="SELECT NAME FROM CREDENTIALS WHERE EMAIL_ID='$key'";
$result=$conn->query($sql);
$r=$result->fetch_assoc();

echo $r['NAME'];


$conn->close();
?>