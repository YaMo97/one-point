/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package onepointverification;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URI;

/**
 *
 * @author lenovo
 */
public class HttpGet {

    public static URL url;
    public static HttpURLConnection httpURLConnection;

    public HttpGet() {
        url = null;
        httpURLConnection = null;
    }

    public static void sendRequest(String targetServlet, String data) {

        try {

            //creating url and connection object
            // String targetURL = new String("http://localhost:7080/OnePointVerificationServer" 
            //                                + targetServlet + "?data=" + data);
            URI uri = new URI("http", "null", "localhost", 7080, "/OnePointVerificationServer" + targetServlet, "data=" + data, null);
//            URI uri = new URI(
//                "http", 
//                "localhost:7080", 
//                "/OnePointVerificationServer" 
//                + targetServlet + "?data=" + data,
//                null);
            URL url = uri.toURL();
            System.out.println(url.toString());
            httpURLConnection = (HttpURLConnection) url.openConnection();

        } catch (Exception e) {
            System.out.println(e);
        }
    }

 public static Reply<Integer,StringBuffer> receiveResponse() {
        int errCode;
        StringBuffer response;
        
        try {
            System.out.println(httpURLConnection.getHeaderField("ErrCode"));
            errCode = Integer.parseInt(httpURLConnection.getHeaderField("ErrCode"));
            
            //Creating input streams
            InputStream is = httpURLConnection.getInputStream();
            BufferedReader rd = new BufferedReader(new InputStreamReader(is));

            String line;
            response = new StringBuffer();

            //Reading from the stream
            while ((line = rd.readLine()) != null) {

                response.append(line);
            }

            rd.close();
            // System.out.println(response);
        } catch (Exception e) {
            System.out.println(e);
            errCode = -2;
            response = new StringBuffer("(HttpPost) Exception Caught: " + e);
        }

        Reply reply = new Reply(errCode, response);
        
        return reply;
    }
}
