/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package onepointverification;

import com.google.gson.Gson;

/**
 *
 * @author lenovo
 */
class teste {
    
    public static void main(String[] args){ 
    
    IndividualDetails individualDetails = new IndividualDetails();
   
    
    }
    
}
