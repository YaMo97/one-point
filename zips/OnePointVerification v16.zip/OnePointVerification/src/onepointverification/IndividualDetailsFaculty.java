/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package onepointverification;

import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Home-PC
 */
public class IndividualDetailsFaculty extends javax.swing.JFrame {

    /**
     * Creates new form IndividualDetailsEmployee
     */
    IndividualDetails individualDetails;

    
    ////////////////////////////////////
    
    private static String str;
    private static StringBuffer strBuff;
    private static StringBuffer replyBuff;
    private static int errCode;

    public IndividualDetailsFaculty() {
        initComponents();
        this.setLocationRelativeTo(null);

        // request for details using  individual type, login id and password 
        // receive all existing details from server
        // set required fields with recieved text
    }

    public IndividualDetailsFaculty(IndividualDetails iD) {
        initComponents();
        this.setLocationRelativeTo(null);

        this.individualDetails = iD;

        // request for existing details using  individual type login id and password 
        /*strBuff = new StringBuffer();
        strBuff.append(iD.getLoginId()).append(";");
        strBuff.append("Faculty").append(";");*/
        String str = new Gson().toJson(individualDetails);
        System.out.println(str);
        HttpPost.sendRequest("/FetchDetails", str, "Faculty");

        // receive all existing details from server
        Reply<Integer, StringBuffer> reply = HttpPost.receiveResponse();
        
        errCode = reply.getKey();
        replyBuff = reply.getObject();
        // individualDetails = new Gson().fromJson(replyBuff.toString(), IndividualDetails.class);
        //check response
        
        System.out.println(replyBuff);

        // StringTokenizer st = new StringTokenizer(replyBuff.toString(), ";");
        // errCode = new StringBuffer(st.nextToken());
        // errCode = HttpPost.receiveResponse();
        // int x = Integer.parseInt(errCode.toString());
        // replyBuff = new StringBuffer(st.nextToken());
        // if responce is positve goto HomePageEmployee
        switch (errCode) {
            case 0: {
                individualDetails = new Gson().fromJson(replyBuff.toString(), IndividualDetails.class);

                System.out.println("(IndividualDetailsFaculty) TextField added!");
                // set required fields with recieved text
                //setFields(individualDetails);
                facultyIdText.setText(individualDetails.getFacultyId());
                fullNameText.setText(individualDetails.getFullName());

                break;
            } // else call ErrorClass

            case 1: {
                System.out.println("(IndividualDetailsFaculty TextField not added! )!");
                break;
            }

            case -1: {
                System.out.println("(IndividualDetailsFaculty Exception at HttpPost.receiveResponse )!");
                break;
            }

            default: {
                System.out.println("(IndividualDetailsFaculty Unknown ErrCode)!");
            }
        }
    }
    
    
    public static List<String> splitEqually(String text, int size) {
        // Give the list the right capacity to start with. You could use an array
        // instead if you wanted.
        List<String> ret = new ArrayList<String>((text.length() + size - 1) / size);

        for (int start = 0; start < text.length(); start += size) {
            ret.add(text.substring(start, Math.min(text.length(), start + size)));
        }
        return ret;
}
  
    private void setFields(IndividualDetails iD) {
        
        facultyIdText.setText(individualDetails.getFacultyId());
        fullNameText.setText(individualDetails.getFullName());
        aadhaarNumberText.setText(iD.getAadhaarNumber());
        fatherNameText.setText(iD.getFatherName());
        motherNameText.setText(iD.getMotherName());
        // dateOfBirthCombo.setText(iD.getDateOfBirth());
        genderCombo.setSelectedItem(iD.getGender());
        maritialStatusCombo.setSelectedItem(iD.getMaritialStatus());
        nationalityText.setText(iD.getNationality());
        
        List<String> address = splitEqually(iD.getCorrespondenceAddress(), 100);
        correspondenceAddressLineOneText.setText(address.get(0));
        correspondenceAddressLineTwoText.setText(address.get(1));
        correspondenceAddressLineThreeText.setText(address.get(2));
        
        if (iD.getPermanentAddress().equals(iD.getCorrespondenceAddress())) {
            yesRadioButton.setSelected(true);
            noRadioButton.setSelected(false);
            address = splitEqually(iD.getCorrespondenceAddress(), 100);
        } else {
            yesRadioButton.setSelected(false);
            noRadioButton.setSelected(true);
        }
        
        permanentAddressLineOneText.setText(address.get(0));
        permanentAddressLineTwoText.setText(address.get(1));
        permanentAddressLineThreeText.setText(address.get(2));
        
        mobileNoText.setText(iD.getMobileNo());
        telephoneNoText.setText(iD.getTelephoneNo());
        emailIdText.setText(iD.getEmailId());
        
        universityNameText.setText(iD.getUniversityName());
        collegeNameText.setText(iD.getCollegeName());
        departmentComboBox.setSelectedItem(iD.getDepartment());
        designationText.setText(iD.getDesignation());
        // joinDateCombo.setSelectedDate(iD.getJoinDate());
        areaOfSpecialisationText.setText(iD.getSpecialArea());
        appointmentTypeText.setText(iD.getAppointmentType());
        instituteAddressLineOneText.setText(iD.getDistrictName());
        instituteAddressLineTwoText.setText(iD.getStateName());
        instituteAddressLineThreeText.setText("India");
        
        bankNameCombo.setSelectedItem(iD.getBankName());
        bankBranchCombo.setSelectedItem(iD.getBankBranch());
        accountNumberText.setText(iD.getAccountNumber());
        panNoText.setText(iD.getPanNo());
        ifscText.setText(iD.getIfsc());
        micrText.setText(iD.getMicr());
    }
    
    private void getFields(IndividualDetails individualDetails) {
        
        individualDetails.setFacultyId(facultyIdText.getText());
        individualDetails.setFullName(fullNameText.getText());
        individualDetails.setAadhaarNumber(aadhaarNumberText.getText());
        individualDetails.setFatherName(fatherNameText.getText());
        individualDetails.setMotherName(motherNameText.getText());
        //individualDetails.setdateOfBirth()
        individualDetails.setGender(genderCombo.getSelectedItem().toString());
        individualDetails.setmaritialStatus(maritialStatusCombo.getSelectedItem().toString());
        individualDetails.setNationality(nationalityText.getText());
        individualDetails.setCorrespondenceAddress(correspondenceAddressLineOneText.getText()
                + correspondenceAddressLineTwoText.getText()
                + correspondenceAddressLineThreeText.getText());
        individualDetails.setPermanentAddress(permanentAddressLineOneText.getText() + " "
                + permanentAddressLineTwoText.getText() + " "
                + permanentAddressLineThreeText.getText());
        individualDetails.setMobileNo(mobileNoText.getText());
        individualDetails.setTelephoneNo(telephoneNoText.getText());
        individualDetails.setEmailId(emailIdText.getText());
        individualDetails.setUniversityName(universityNameText.getText());
        individualDetails.setCollegeName(collegeNameText.getText());
        individualDetails.setDepartment(departmentComboBox.getSelectedItem().toString());
        individualDetails.setDesignation(designationText.getText());
        // joinDate = joinDateCombo.getSelectedDate().getTime();
        // System.out.println(joinDate);
        individualDetails.setSpecialArea(areaOfSpecialisationText.getText());
        individualDetails.setAppointmentType(appointmentTypeText.getText());
        individualDetails.setDistrictName(instituteAddressLineTwoText.getText());
        individualDetails.setStateName(instituteAddressLineThreeText.getText());
        individualDetails.setPanNo(panNoText.getText());
        individualDetails.setBankName(bankNameCombo.getSelectedItem().toString());
        individualDetails.setBankBranch(bankBranchCombo.getSelectedItem().toString());
        individualDetails.setAccountNumber(accountNumberText.getText());
        individualDetails.setIfsc(ifscText.getText());
        individualDetails.setMicr(micrText.getText());
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        telephoneNoText = new javax.swing.JTextField();
        genderCombo = new javax.swing.JComboBox();
        jLabel10 = new javax.swing.JLabel();
        nationalityText = new javax.swing.JTextField();
        fullNameText = new javax.swing.JTextField();
        fatherNameText = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        correspondenceAddressLineOneText = new javax.swing.JTextField();
        maritialStatusCombo = new javax.swing.JComboBox();
        mobileNoText = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        permanentAddressLineOneText = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        noRadioButton = new javax.swing.JRadioButton();
        yesRadioButton = new javax.swing.JRadioButton();
        permanentAddressLineThreeText = new javax.swing.JTextField();
        correspondenceAddressLineTwoText = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        emailIdText = new javax.swing.JTextField();
        aadhaarNumberText = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        permanentAddressLineTwoText = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        motherNameText = new javax.swing.JTextField();
        correspondenceAddressLineThreeText = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        facultyIdText = new javax.swing.JTextField();
        logoutFacultyButton = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        bankNameCombo = new javax.swing.JComboBox();
        jLabel27 = new javax.swing.JLabel();
        bankBranchCombo = new javax.swing.JComboBox();
        jLabel28 = new javax.swing.JLabel();
        panNoText = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        ifscText = new javax.swing.JTextField();
        jLabel32 = new javax.swing.JLabel();
        micrText = new javax.swing.JTextField();
        accountNumberText = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        designationText = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        departmentComboBox = new javax.swing.JComboBox();
        jLabel21 = new javax.swing.JLabel();
        areaOfSpecialisationText = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        appointmentTypeText = new javax.swing.JTextField();
        instituteAddressLineOneText = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        instituteAddressLineTwoText = new javax.swing.JTextField();
        instituteAddressLineThreeText = new javax.swing.JTextField();
        universityNameText = new javax.swing.JTextField();
        collegeNameText = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        verifyButton = new javax.swing.JButton();
        clearButton = new javax.swing.JButton();
        printButton = new javax.swing.JButton();
        editButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel7.setText("Gender");

        genderCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel10.setText("Correspondence Address   ");

        fullNameText.setEditable(false);
        fullNameText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fullNameTextActionPerformed(evt);
            }
        });

        jLabel13.setText("Mobile No.");

        jLabel1.setText("Personal Details");

        maritialStatusCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        mobileNoText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mobileNoTextActionPerformed(evt);
            }
        });

        jLabel11.setText("Is Permanent Address same as Correspondance Address");

        jLabel26.setText("Email-ID");

        jLabel9.setText("Nationality");

        noRadioButton.setText("No");

        yesRadioButton.setText("Yes");

        jLabel3.setText("Aadhar No.");

        aadhaarNumberText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aadhaarNumberTextActionPerformed(evt);
            }
        });

        jLabel4.setText("Father's Name");

        jLabel12.setText("Permanent Address");

        jLabel5.setText("Mother's Name");

        jLabel8.setText("Marital Status");

        jLabel6.setText("Date of Birth");

        jLabel14.setText("Telephone No.");

        jLabel2.setText("Full Name");

        jLabel24.setText("Faculty ID");

        facultyIdText.setEditable(false);

        logoutFacultyButton.setText("Logout Faculty");
        logoutFacultyButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutFacultyButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12)
                    .addComponent(jLabel13)
                    .addComponent(jLabel26)
                    .addComponent(jLabel1)
                    .addComponent(jLabel24))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(56, 56, 56)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(emailIdText, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(mobileNoText, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(52, 52, 52)
                                .addComponent(jLabel14)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(telephoneNoText, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(correspondenceAddressLineTwoText)
                                .addComponent(correspondenceAddressLineThreeText)
                                .addGroup(jPanel3Layout.createSequentialGroup()
                                    .addComponent(yesRadioButton)
                                    .addGap(43, 43, 43)
                                    .addComponent(noRadioButton))
                                .addComponent(permanentAddressLineThreeText)
                                .addComponent(permanentAddressLineTwoText)
                                .addComponent(permanentAddressLineOneText)
                                .addComponent(nationalityText)
                                .addComponent(motherNameText)
                                .addComponent(fatherNameText)
                                .addComponent(fullNameText)
                                .addComponent(aadhaarNumberText)
                                .addComponent(correspondenceAddressLineOneText)
                                .addComponent(facultyIdText)
                                .addComponent(maritialStatusCombo, 0, 192, Short.MAX_VALUE)
                                .addComponent(genderCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(51, 51, 51))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(logoutFacultyButton)
                        .addContainerGap())))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(logoutFacultyButton))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel24)
                    .addComponent(facultyIdText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(fullNameText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(aadhaarNumberText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(fatherNameText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(motherNameText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(genderCombo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(maritialStatusCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(nationalityText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(correspondenceAddressLineOneText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(12, 12, 12)
                        .addComponent(correspondenceAddressLineTwoText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(correspondenceAddressLineThreeText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(yesRadioButton)
                            .addComponent(noRadioButton))
                        .addGap(54, 54, 54))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(permanentAddressLineOneText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel12)))
                .addGap(15, 15, 15)
                .addComponent(permanentAddressLineTwoText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addComponent(permanentAddressLineThreeText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(emailIdText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel26)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(mobileNoText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14)
                            .addComponent(telephoneNoText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(40, 40, 40)))
                .addContainerGap(27, Short.MAX_VALUE))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel25.setText("Bank Name");

        bankNameCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel27.setText("Bank Branch");

        bankBranchCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel28.setText("Account No.");
        jLabel28.setToolTipText("");

        panNoText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                panNoTextActionPerformed(evt);
            }
        });

        jLabel29.setText("Pan No.");

        jLabel30.setText("IFSC");

        jLabel31.setText("Bank Details");
        jLabel31.setToolTipText("");

        ifscText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ifscTextActionPerformed(evt);
            }
        });

        jLabel32.setText("MICR");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel31)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel32)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel25)
                                    .addComponent(jLabel27)
                                    .addComponent(jLabel28)
                                    .addComponent(jLabel29)
                                    .addComponent(jLabel30))
                                .addGap(154, 154, 154)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(bankBranchCombo, 0, 191, Short.MAX_VALUE)
                                    .addComponent(panNoText, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(ifscText, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(micrText, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bankNameCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(accountNumberText))))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel31)
                .addGap(34, 34, 34)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(bankNameCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bankBranchCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel27))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28)
                    .addComponent(accountNumberText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel29)
                    .addComponent(panNoText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel30)
                    .addComponent(ifscText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel32)
                    .addComponent(micrText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel16.setText("University");

        jLabel17.setText("College");

        jLabel18.setText("Department");

        designationText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                designationTextActionPerformed(evt);
            }
        });

        jLabel19.setText("Designation");

        jLabel20.setText("Date Of Joining");

        jLabel15.setText("Professional Details");

        departmentComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel21.setText("Area of Specialisation");

        jLabel22.setText("Appointment Type");

        instituteAddressLineOneText.setEditable(false);

        jLabel23.setText("Institute Address");

        instituteAddressLineTwoText.setEditable(false);
        instituteAddressLineTwoText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                instituteAddressLineTwoTextActionPerformed(evt);
            }
        });

        instituteAddressLineThreeText.setEditable(false);

        universityNameText.setEditable(false);

        collegeNameText.setEditable(false);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel21)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel16)
                                    .addComponent(jLabel17)
                                    .addComponent(jLabel18)
                                    .addComponent(jLabel19)
                                    .addComponent(jLabel20))
                                .addGap(139, 139, 139)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(collegeNameText, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(departmentComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(universityNameText, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel22)
                                    .addComponent(jLabel23))
                                .addGap(121, 121, 121)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(instituteAddressLineOneText, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(instituteAddressLineTwoText, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(instituteAddressLineThreeText, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(designationText, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(areaOfSpecialisationText, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(appointmentTypeText, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel15)
                .addGap(34, 34, 34)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(universityNameText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(collegeNameText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(departmentComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(designationText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel20)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(areaOfSpecialisationText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(appointmentTypeText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22))
                .addGap(24, 24, 24)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(instituteAddressLineOneText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(instituteAddressLineTwoText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(instituteAddressLineThreeText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        verifyButton.setText("Verify");
        verifyButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                verifyButtonActionPerformed(evt);
            }
        });

        clearButton.setText("Clear");
        clearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearButtonActionPerformed(evt);
            }
        });

        printButton.setText("Print");
        printButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printButtonActionPerformed(evt);
            }
        });

        editButton.setText("Edit");
        editButton.setToolTipText("");
        editButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(203, 203, 203)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(verifyButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(printButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(55, 55, 55)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(clearButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(editButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(verifyButton)
                    .addComponent(clearButton))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(printButton)
                    .addComponent(editButton))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(126, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(84, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(420, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 912, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1587, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void fullNameTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fullNameTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fullNameTextActionPerformed

    private void mobileNoTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mobileNoTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_mobileNoTextActionPerformed

    private void panNoTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_panNoTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_panNoTextActionPerformed

    private void ifscTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ifscTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ifscTextActionPerformed

    private void designationTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_designationTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_designationTextActionPerformed

    private void instituteAddressLineTwoTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_instituteAddressLineTwoTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_instituteAddressLineTwoTextActionPerformed

    private void verifyButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_verifyButtonActionPerformed
        // TODO add your handling code here:

        getFields(individualDetails);
        
        // check details for proper format
        str = new Gson().toJson(individualDetails);
        
        System.out.println(this + str); // Debug
        // send opcode to server
        // send details to server
        HttpPost.sendRequest("/Verify", str, "Faculty");

        // wait for response and show loading(Thread)
        // receive response from server
        Reply<Integer, StringBuffer> reply = HttpPost.receiveResponse();
        
        errCode = reply.getKey();
        replyBuff = reply.getObject();
        // generate errorcode from replyBuff
        // if reponse positive enable print button and show success and send email     
        // else act according to error code
        switch (errCode) //DEBUG
        {
            case 0:
                //success
                System.out.println("(IndividualDetailsFaculty) Verification Successful!");
                JOptionPane.showMessageDialog(this, "(IndividualDetailsFaculty) Verification Successful!");
                break;
            case 1:
                //success
                System.out.println("(IndividualDetailsFaculty) Full Name Does Not Match!");
                JOptionPane.showMessageDialog(this, "(IndividualDetailsFaculty) Full Name Does Not Match!");
                break;
            case 2:
                //success
                System.out.println("(IndividualDetailsFaculty) Aadhar not Match!");
                JOptionPane.showMessageDialog(this, "(IndividualDetailsFaculty) Aadhar not Match!");
                break;
            default:
                // error
                JOptionPane.showMessageDialog(this, "(IndividualDetailsFaculty) Verification Failed! (" + errCode + ")");
                System.out.println("(IndividualDetailsFaculty) Verification Failed! (" + errCode + ")");
        }
    }//GEN-LAST:event_verifyButtonActionPerformed

    private void clearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearButtonActionPerformed
        // TODO add your handling code here:

        // clear editables fields
    }//GEN-LAST:event_clearButtonActionPerformed

    private void printButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printButtonActionPerformed
        // TODO add your handling code here:

        // Print Page
    }//GEN-LAST:event_printButtonActionPerformed

    private void editButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editButtonActionPerformed
        // TODO add your handling code here:

        // men at work
    }//GEN-LAST:event_editButtonActionPerformed

    private void logoutFacultyButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutFacultyButtonActionPerformed
        // TODO add your handling code here:
        new IndividualLogin().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_logoutFacultyButtonActionPerformed

    private void aadhaarNumberTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aadhaarNumberTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_aadhaarNumberTextActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(IndividualDetailsFaculty.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(IndividualDetailsFaculty.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(IndividualDetailsFaculty.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(IndividualDetailsFaculty.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new IndividualDetailsFaculty().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField aadhaarNumberText;
    private javax.swing.JTextField accountNumberText;
    private javax.swing.JTextField appointmentTypeText;
    private javax.swing.JTextField areaOfSpecialisationText;
    private javax.swing.JComboBox bankBranchCombo;
    private javax.swing.JComboBox bankNameCombo;
    private javax.swing.JButton clearButton;
    private javax.swing.JTextField collegeNameText;
    private javax.swing.JTextField correspondenceAddressLineOneText;
    private javax.swing.JTextField correspondenceAddressLineThreeText;
    private javax.swing.JTextField correspondenceAddressLineTwoText;
    private javax.swing.JComboBox departmentComboBox;
    private javax.swing.JTextField designationText;
    private javax.swing.JButton editButton;
    private javax.swing.JTextField emailIdText;
    private javax.swing.JTextField facultyIdText;
    private javax.swing.JTextField fatherNameText;
    private javax.swing.JTextField fullNameText;
    private javax.swing.JComboBox genderCombo;
    private javax.swing.JTextField ifscText;
    private javax.swing.JTextField instituteAddressLineOneText;
    private javax.swing.JTextField instituteAddressLineThreeText;
    private javax.swing.JTextField instituteAddressLineTwoText;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton logoutFacultyButton;
    private javax.swing.JComboBox maritialStatusCombo;
    private javax.swing.JTextField micrText;
    private javax.swing.JTextField mobileNoText;
    private javax.swing.JTextField motherNameText;
    private javax.swing.JTextField nationalityText;
    private javax.swing.JRadioButton noRadioButton;
    private javax.swing.JTextField panNoText;
    private javax.swing.JTextField permanentAddressLineOneText;
    private javax.swing.JTextField permanentAddressLineThreeText;
    private javax.swing.JTextField permanentAddressLineTwoText;
    private javax.swing.JButton printButton;
    private javax.swing.JTextField telephoneNoText;
    private javax.swing.JTextField universityNameText;
    private javax.swing.JButton verifyButton;
    private javax.swing.JRadioButton yesRadioButton;
    // End of variables declaration//GEN-END:variables
}
