/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package onepointverification;

/**
 *
 * @author lenovo
 */
public class Reply<T, U> {

    public T key;
    public U object;

    public Reply(){
        key = null;
        object = null;
    };
    
    public Reply (T key, U object) {
        this.key = key;
        this.object = object;
    }

    public T getKey() {
        return key;
    }

    public U getObject() {
        return object;
    }
}