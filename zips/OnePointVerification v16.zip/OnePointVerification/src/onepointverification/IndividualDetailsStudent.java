/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package onepointverification;

import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * @author Home-PC
 */
public class IndividualDetailsStudent extends javax.swing.JFrame {

    /**
     * Creates new form IndividualDetailsStudent
     */
    IndividualDetails individualDetails;

    private static StringBuffer strBuff;
    private static String str;
    private static StringBuffer replyBuff;
    private static int errCode;

    public IndividualDetailsStudent() {
        initComponents();
        this.setLocationRelativeTo(null);

        // request for details using  individual type login id and password 
        // receive all existing details from server
        // set required fields with recieved text
    }

    public IndividualDetailsStudent(IndividualDetails iD) {
        initComponents();
        this.setLocationRelativeTo(null);
        this.individualDetails = iD;

        // request for existing details using  individual type login id and password 
        /*strBuff = new StringBuffer();
        strBuff.append(iD.getLoginId()).append(";");
        strBuff.append("Student").append(";");*/
        str = new Gson().toJson(individualDetails);
        System.out.println(str);
        HttpPost.sendRequest("/FetchDetails", str, "Student");

        // receive all existing details from server
        Reply<Integer, StringBuffer> reply = HttpPost.receiveResponse();
        
        errCode = reply.getKey();
        replyBuff = reply.getObject();
        // individualDetails = new Gson().fromJson(replyBuff.toString(), IndividualDetails.class);
        //check response
        System.out.println(replyBuff);

        // StringTokenizer st = new StringTokenizer(replyBuff.toString(), ";");
        // errCode = new StringBuffer(st.nextToken());
        // errCode = HttpPost.receiveResponse();
        // int x = Integer.parseInt(errCode.toString());
        // replyBuff = new StringBuffer(st.nextToken());
        // if responce is positve goto HomePageEmployee
        switch (errCode) {
            case 0: {
                individualDetails = new Gson().fromJson(replyBuff.toString(), IndividualDetails.class);
                
                
                // set required fields with recieved text
                setFields(individualDetails);
                //studentIdText.setText(individualDetails.getStudentId());
                //fullNameText.setText(individualDetails.getFullName());
                System.out.println("(IndividualDetailsStudent) TextField added!");
                
                break;
            } // else call ErrorClass

            case 1: {
                System.out.println("(IndividualDetailsStudent TextField not added! )!");
                break;
            }

            case -1: {
                System.out.println("(IndividualDetailsStudent Exception at HttpPost.receiveResponse )!");
                break;
            }

            default: {
                System.out.println("(IndividualDetailsStudent Unknown ErrCode)!");
            }
        }
    }

    public static ArrayList<String> splitEqually(String text, int size) {
        // Give the list the right capacity to start with. You could use an array
        // instead if you wanted.
        ArrayList<String> ret = new ArrayList<String>((text.length() + size - 1) / size);

        for (int start = 0; start < text.length(); start += size) {
            ret.add(text.substring(start, Math.min(text.length(), start + size)));
        }
        return ret;
    }

    private void setFields(IndividualDetails iD) {
        
        studentIdText.setText(iD.getStudentId());
        fullNameText.setText(iD.getFullName());
        
        aadhaarNumberText.setText(iD.getAadhaarNumber());
        fatherNameText.setText(iD.getFatherName());
        motherNameText.setText(iD.getMotherName());
        try{
            Calendar cal = Calendar.getInstance();
            SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy hh:mm:ss aa");
            Date dateOfBirth = sdf.parse(iD.getDateOfBirth());
            cal.setTime(dateOfBirth);
            dateOfBirthCombo.setSelectedDate(cal);
        } catch (Exception ex) { System.out.println("Personal Detils dateofbirth: Caught: " + ex); }
        
        
        if (!(iD.getGender() == null))
            genderCombo.setSelectedItem(iD.getGender());
        if (!(iD.getMaritialStatus() == null))
            maritialStatusCombo.setSelectedItem(iD.getMaritialStatus());
        nationalityText.setText(iD.getNationality());

//        ArrayList<String> address;
//        
//        if (!(iD.getCorrespondenceAddress() == null)    ) {
//            
//            address = splitEqually(iD.getCorrespondenceAddress(), 100);
//            correspondenceAddressLineOneText.setText(address.get(0));
//            correspondenceAddressLineTwoText.setText(address.get(1));
//            correspondenceAddressLineThreeText.setText(address.get(2));
//
//        }
//
//        if (iD.getPermanentAddress().equals(iD.getCorrespondenceAddress())) {
//            yesRadioButton.setSelected(true);
//            noRadioButton.setSelected(false);
//            address = splitEqually(iD.getCorrespondenceAddress(), 100);
//        } else {
//            yesRadioButton.setSelected(false);
//            noRadioButton.setSelected(true);
//        }
//
//        permanentAddressLineOneText.setText(address.get(0));
//        permanentAddressLineTwoText.setText(address.get(1));
//        permanentAddressLineThreeText.setText(address.get(2));

        mobileNoText.setText(iD.getMobileNo());
        telephoneNoText.setText(iD.getTelephoneNo());
        emailIdText.setText(iD.getEmailId());

        universityNameText.setText(iD.getUniversityName());
        collegeNameText.setText(iD.getCollegeName());
        if (!(iD.getCourse() == null))
            courseCombo.setSelectedItem(iD.getCourse());
        branchText.setText(iD.getBranch());
//        startDateCombo.setSelectedDate(iD.getStartDate());
//        endDateCombo.setSelectedDate(iD.getEndDate());
//        yearText.setText("" + iD.getCurrentYear());
        instituteAddressLineOneText.setText(iD.getDistrictName());
        instituteAddressLineTwoText.setText(iD.getStateName());
        instituteAddressLineThreeText.setText("India");

        if (!(iD.getBankName() == null))
            bankNameCombo.setSelectedItem(iD.getBankName());
        if (!(iD.getBankBranch()== null))
            bankBranchCombo.setSelectedItem(iD.getBankBranch());
        
        accountNumberText.setText(iD.getAccountNumber());
        panNoText.setText(iD.getPanNo());
        ifscText.setText(iD.getIfsc());
        micrText.setText(iD.getMicr());
    }
    
    private IndividualDetails getFields(IndividualDetails iD) {
        
        iD.setStudentId(studentIdText.getText());
        iD.setFullName(fullNameText.getText());
        
        iD.setAadhaarNumber(aadhaarNumberText.getText());
        iD.setFatherName(fatherNameText.getText());
        iD.setMotherName(motherNameText.getText());
        //dateOfBirth
        if (!(genderCombo.getSelectedItem().toString().equals("----")))
            iD.setGender(genderCombo.getSelectedItem().toString());
        if (!(maritialStatusCombo.getSelectedItem().toString().equals("----")))
            iD.setmaritialStatus(maritialStatusCombo.getSelectedItem().toString());
        iD.setNationality(nationalityText.getText());
        iD.setCorrespondenceAddress(correspondenceAddressLineOneText.getText()
                + correspondenceAddressLineTwoText.getText()
                + correspondenceAddressLineThreeText.getText());
        iD.setPermanentAddress(permanentAddressLineOneText.getText() + " "
                + permanentAddressLineTwoText.getText() + " "
                + permanentAddressLineThreeText.getText());
        iD.setMobileNo(mobileNoText.getText());
        iD.setTelephoneNo(telephoneNoText.getText());
        iD.setEmailId(emailIdText.getText());
        iD.setUniversityName(universityNameText.getText());
        iD.setCollegeName(collegeNameText.getText());
        if (!(courseCombo.getSelectedItem().toString().equals("----")))
            iD.setCourse(courseCombo.getSelectedItem().toString());
        iD.setBranch(branchText.getText());

        //startDate = startDateCombo.getSelectedDate().getTime();
        //endDate = endDateCombo.getSelectedDate().getTime();
        iD.setDistrictName(instituteAddressLineTwoText.getText());
        iD.setStateName(instituteAddressLineThreeText.getText());
        iD.setPanNo(panNoText.getText());
        
        if (!(bankNameCombo.getSelectedItem().toString().equals("----")))
            iD.setBankName(bankNameCombo.getSelectedItem().toString());
        if (!(bankBranchCombo.getSelectedItem().toString().equals("----")))
            iD.setBankBranch(bankBranchCombo.getSelectedItem().toString());
        
        iD.setAccountNumber(accountNumberText.getText());
        iD.setIfsc(ifscText.getText());
        iD.setMicr(micrText.getText());
        
        return iD;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        telephoneNoText = new javax.swing.JTextField();
        genderCombo = new javax.swing.JComboBox();
        jLabel10 = new javax.swing.JLabel();
        nationalityText = new javax.swing.JTextField();
        fullNameText = new javax.swing.JTextField();
        fatherNameText = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        correspondenceAddressLineOneText = new javax.swing.JTextField();
        maritialStatusCombo = new javax.swing.JComboBox();
        mobileNoText = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        permanentAddressLineOneText = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        noRadioButton = new javax.swing.JRadioButton();
        yesRadioButton = new javax.swing.JRadioButton();
        permanentAddressLineThreeText = new javax.swing.JTextField();
        correspondenceAddressLineTwoText = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        emailIdText = new javax.swing.JTextField();
        aadhaarNumberText = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        permanentAddressLineTwoText = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        motherNameText = new javax.swing.JTextField();
        correspondenceAddressLineThreeText = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        studentIdText = new javax.swing.JTextField();
        logoutStudentButton = new javax.swing.JButton();
        dateOfBirthCombo = new datechooser.beans.DateChooserCombo();
        jPanel4 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        bankNameCombo = new javax.swing.JComboBox();
        jLabel28 = new javax.swing.JLabel();
        panNoText = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        ifscText = new javax.swing.JTextField();
        jLabel32 = new javax.swing.JLabel();
        micrText = new javax.swing.JTextField();
        accountNumberText = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        bankBranchCombo = new javax.swing.JComboBox();
        jPanel5 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        branchText = new javax.swing.JTextField();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        courseCombo = new javax.swing.JComboBox();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        yearText = new javax.swing.JTextField();
        instituteAddressLineOneText = new javax.swing.JTextField();
        jLabel42 = new javax.swing.JLabel();
        instituteAddressLineTwoText = new javax.swing.JTextField();
        instituteAddressLineThreeText = new javax.swing.JTextField();
        universityNameText = new javax.swing.JTextField();
        collegeNameText = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        verifyButton = new javax.swing.JButton();
        clearButton = new javax.swing.JButton();
        printButton = new javax.swing.JButton();
        editButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jScrollPane1.setToolTipText("");

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel7.setText("Gender");

        genderCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "----", "M", "F" }));
        genderCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                genderComboActionPerformed(evt);
            }
        });

        jLabel10.setText("Correspondence Address   ");

        fullNameText.setEditable(false);
        fullNameText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fullNameTextActionPerformed(evt);
            }
        });

        jLabel13.setText("Mobile No.");

        jLabel1.setText("Personal Details");

        maritialStatusCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "----", "Unmarried", "Married" }));
        maritialStatusCombo.setToolTipText("");

        mobileNoText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mobileNoTextActionPerformed(evt);
            }
        });

        jLabel11.setText("Is Permanent Address same as Correspondance Address");

        jLabel26.setText("Email-ID");

        jLabel9.setText("Nationality");

        noRadioButton.setSelected(true);
        noRadioButton.setText("No");

        yesRadioButton.setText("Yes");

        permanentAddressLineThreeText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                permanentAddressLineThreeTextActionPerformed(evt);
            }
        });

        jLabel3.setText("Aadhar No.");

        jLabel4.setText("Father's Name");

        jLabel12.setText("Permanent Address");

        jLabel5.setText("Mother's Name");

        jLabel8.setText("Marital Status");

        jLabel6.setText("Date of Birth");

        jLabel14.setText("Telephone No.");

        jLabel2.setText("Full Name");

        jLabel15.setText("Student ID");

        studentIdText.setEditable(false);
        studentIdText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentIdTextActionPerformed(evt);
            }
        });

        logoutStudentButton.setText("Logout Student");
        logoutStudentButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutStudentButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12)
                    .addComponent(jLabel13)
                    .addComponent(jLabel26)
                    .addComponent(jLabel1)
                    .addComponent(jLabel15))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(56, 56, 56)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(emailIdText, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(mobileNoText, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(32, 32, 32)
                                .addComponent(jLabel14)
                                .addGap(43, 43, 43)
                                .addComponent(telephoneNoText, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(dateOfBirthCombo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(studentIdText, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(correspondenceAddressLineTwoText, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 192, Short.MAX_VALUE)
                                .addComponent(correspondenceAddressLineThreeText, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 192, Short.MAX_VALUE)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                    .addComponent(yesRadioButton)
                                    .addGap(43, 43, 43)
                                    .addComponent(noRadioButton))
                                .addComponent(permanentAddressLineThreeText, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 192, Short.MAX_VALUE)
                                .addComponent(permanentAddressLineTwoText, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(permanentAddressLineOneText, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(nationalityText, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 192, Short.MAX_VALUE)
                                .addComponent(motherNameText, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(fatherNameText, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(fullNameText, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(aadhaarNumberText, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(correspondenceAddressLineOneText, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(maritialStatusCombo, javax.swing.GroupLayout.Alignment.LEADING, 0, 192, Short.MAX_VALUE)
                                .addComponent(genderCombo, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addContainerGap(86, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(logoutStudentButton)
                        .addContainerGap())))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addComponent(logoutStudentButton))
                        .addGap(21, 21, 21)
                        .addComponent(jLabel15))
                    .addComponent(studentIdText, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(fullNameText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(aadhaarNumberText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(fatherNameText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(motherNameText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel6)
                    .addComponent(dateOfBirthCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(genderCombo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(maritialStatusCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(nationalityText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(correspondenceAddressLineOneText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(12, 12, 12)
                        .addComponent(correspondenceAddressLineTwoText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(correspondenceAddressLineThreeText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(yesRadioButton)
                            .addComponent(noRadioButton))
                        .addGap(54, 54, 54))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(permanentAddressLineOneText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel12)))
                .addGap(15, 15, 15)
                .addComponent(permanentAddressLineTwoText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(permanentAddressLineThreeText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(emailIdText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel26)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(mobileNoText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14)
                            .addComponent(telephoneNoText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(49, 49, 49)))
                .addContainerGap(27, Short.MAX_VALUE))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel25.setText("Bank Name");

        bankNameCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "----" }));

        jLabel28.setText("Account No.");
        jLabel28.setToolTipText("");

        panNoText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                panNoTextActionPerformed(evt);
            }
        });

        jLabel29.setText("Pan No.");

        jLabel30.setText("IFSC");

        jLabel31.setText("Bank Details");
        jLabel31.setToolTipText("");

        ifscText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ifscTextActionPerformed(evt);
            }
        });

        jLabel32.setText("MICR");

        jLabel27.setText("Bank Branch");

        bankBranchCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "----" }));
        bankBranchCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bankBranchComboActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel31)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel32)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel25)
                                    .addComponent(jLabel28)
                                    .addComponent(jLabel29)
                                    .addComponent(jLabel30))
                                .addGap(154, 154, 154)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(panNoText, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(ifscText, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(micrText, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bankNameCombo, 0, 191, Short.MAX_VALUE)
                                    .addComponent(accountNumberText)))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel27)
                                .addGap(154, 154, 154)
                                .addComponent(bankBranchCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel31)
                .addGap(34, 34, 34)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(bankNameCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bankBranchCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel27))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28)
                    .addComponent(accountNumberText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel29)
                    .addComponent(panNoText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel30)
                    .addComponent(ifscText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel32)
                    .addComponent(micrText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        jPanel5.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel34.setText("University");

        jLabel35.setText("College");

        jLabel36.setText("Course");

        branchText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                branchTextActionPerformed(evt);
            }
        });

        jLabel37.setText("Branch");

        jLabel38.setText("Start Date");

        jLabel39.setText("Professional Details");

        courseCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "----" }));

        jLabel40.setText("End Date");

        jLabel41.setText("Year");

        instituteAddressLineOneText.setEditable(false);

        jLabel42.setText("Institute Address");

        instituteAddressLineTwoText.setEditable(false);
        instituteAddressLineTwoText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                instituteAddressLineTwoTextActionPerformed(evt);
            }
        });

        instituteAddressLineThreeText.setEditable(false);

        universityNameText.setEditable(false);

        collegeNameText.setEditable(false);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel39)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel34)
                                    .addComponent(jLabel35)
                                    .addComponent(jLabel36)
                                    .addComponent(jLabel37)
                                    .addComponent(jLabel38))
                                .addGap(159, 159, 159)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(courseCombo, 0, 191, Short.MAX_VALUE)
                                    .addComponent(branchText, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(universityNameText)
                                    .addComponent(collegeNameText)))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel41)
                                    .addComponent(jLabel42)
                                    .addComponent(jLabel40))
                                .addGap(121, 121, 121)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(instituteAddressLineOneText, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(yearText, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(instituteAddressLineTwoText, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(instituteAddressLineThreeText, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 311, Short.MAX_VALUE))))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel39)
                .addGap(34, 34, 34)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel34)
                    .addComponent(universityNameText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel35)
                    .addComponent(collegeNameText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(courseCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel36))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel37)
                    .addComponent(branchText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel38)
                .addGap(20, 20, 20)
                .addComponent(jLabel40)
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(yearText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel41))
                .addGap(24, 24, 24)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel42)
                    .addComponent(instituteAddressLineOneText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(instituteAddressLineTwoText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(instituteAddressLineThreeText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        verifyButton.setText("Verify");
        verifyButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                verifyButtonActionPerformed(evt);
            }
        });

        clearButton.setText("Clear");
        clearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearButtonActionPerformed(evt);
            }
        });

        printButton.setText("Print");
        printButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printButtonActionPerformed(evt);
            }
        });

        editButton.setText("Edit");
        editButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(229, 229, 229)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(verifyButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(printButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(47, 47, 47)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(clearButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(editButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(288, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(clearButton)
                    .addComponent(verifyButton))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(printButton)
                    .addComponent(editButton))
                .addContainerGap(32, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(125, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(78, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(63, 63, 63)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(2471, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1587, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void fullNameTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fullNameTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fullNameTextActionPerformed

    private void mobileNoTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mobileNoTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_mobileNoTextActionPerformed

    private void panNoTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_panNoTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_panNoTextActionPerformed

    private void ifscTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ifscTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ifscTextActionPerformed

    private void branchTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_branchTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_branchTextActionPerformed

    private void instituteAddressLineTwoTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_instituteAddressLineTwoTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_instituteAddressLineTwoTextActionPerformed

    private void studentIdTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentIdTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_studentIdTextActionPerformed

    private void genderComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_genderComboActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_genderComboActionPerformed

    private void permanentAddressLineThreeTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_permanentAddressLineThreeTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_permanentAddressLineThreeTextActionPerformed

    private void clearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearButtonActionPerformed
        // TODO add your handling code here:

        // clear editables fields
    }//GEN-LAST:event_clearButtonActionPerformed

    private void verifyButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_verifyButtonActionPerformed
        // TODO add your handling code here:

        individualDetails = getFields(individualDetails);
        
        // check details for proper format
        String str = new Gson().toJson(individualDetails);
        
        System.out.println(this + str);
        // send opcode to server
        // send details to server
        HttpPost.sendRequest("/Verify", str, "Student");

        // wait for response and show loading(Thread)
        // receive response f   rom server
        Reply<Integer, StringBuffer> reply = HttpPost.receiveResponse();
        
        errCode = reply.getKey();
        replyBuff = reply.getObject();

        // generate errorcode from replyBuff
        // if reponse positive enable print button and show success and send email     
        // else act according to error code
        switch (errCode) //DEBUG
        {
            case 0:
                //success
                System.out.println("(IndividualDetailsStudent) Verification Successful!");
                JOptionPane.showMessageDialog(this, "(IndividualDetailsStudent) Verification Successful!");
                break;
            case 1:
                //success
                System.out.println("(IndividualDetailsStudent) Full Name Does Not Match!");
                JOptionPane.showMessageDialog(this, "(IndividualDetailsStudent) Full Name Does Not Match!");
                break;
            case 2:
                //success
                System.out.println("(IndividualDetailsStudent) Aadhar not Match!");
                JOptionPane.showMessageDialog(this, "(IndividualDetailsStudent) Aadhar not Match!");
                break;
            default:
                // error
                JOptionPane.showMessageDialog(this, "(IndividualDetailsStudent) Verification Failed! (" + errCode + ")");
                System.out.println("(IndividualDetailsStudent) Verification Failed! (" + errCode + ")");
        }

        // for each detail/variable 4 error codes:
        // 0 : if matching
        // 1 : if not matchings
        // 2 : missing in database
        // 3 : not provided in form(only for non mandatory)
//        while (detail.hasNext())
//        {
//                switch(detail.errCode)
//                {
//                case 0:
//                        break;
//
//                case 1:
//                        break;
//
//                case 2:
//                        break;
//
//                case 3:
//                        break;
//
//                default:
//                }
//        }

    }//GEN-LAST:event_verifyButtonActionPerformed

    private void printButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printButtonActionPerformed
        // TODO add your handling code here:

        // Print page
    }//GEN-LAST:event_printButtonActionPerformed

    private void editButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editButtonActionPerformed
        // TODO add your handling code here:

        // men at work
    }//GEN-LAST:event_editButtonActionPerformed

    private void logoutStudentButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutStudentButtonActionPerformed
        // TODO add your handling code here:
        new IndividualLogin().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_logoutStudentButtonActionPerformed

    private void bankBranchComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bankBranchComboActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bankBranchComboActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(IndividualDetailsStudent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(IndividualDetailsStudent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(IndividualDetailsStudent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(IndividualDetailsStudent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new IndividualDetailsStudent().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField aadhaarNumberText;
    private javax.swing.JTextField accountNumberText;
    private javax.swing.JComboBox bankBranchCombo;
    private javax.swing.JComboBox bankNameCombo;
    private javax.swing.JTextField branchText;
    private javax.swing.JButton clearButton;
    private javax.swing.JTextField collegeNameText;
    private javax.swing.JTextField correspondenceAddressLineOneText;
    private javax.swing.JTextField correspondenceAddressLineThreeText;
    private javax.swing.JTextField correspondenceAddressLineTwoText;
    private javax.swing.JComboBox courseCombo;
    private datechooser.beans.DateChooserCombo dateOfBirthCombo;
    private javax.swing.JButton editButton;
    private javax.swing.JTextField emailIdText;
    private javax.swing.JTextField fatherNameText;
    private javax.swing.JTextField fullNameText;
    private javax.swing.JComboBox genderCombo;
    private javax.swing.JTextField ifscText;
    private javax.swing.JTextField instituteAddressLineOneText;
    private javax.swing.JTextField instituteAddressLineThreeText;
    private javax.swing.JTextField instituteAddressLineTwoText;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton logoutStudentButton;
    private javax.swing.JComboBox maritialStatusCombo;
    private javax.swing.JTextField micrText;
    private javax.swing.JTextField mobileNoText;
    private javax.swing.JTextField motherNameText;
    private javax.swing.JTextField nationalityText;
    private javax.swing.JRadioButton noRadioButton;
    private javax.swing.JTextField panNoText;
    private javax.swing.JTextField permanentAddressLineOneText;
    private javax.swing.JTextField permanentAddressLineThreeText;
    private javax.swing.JTextField permanentAddressLineTwoText;
    private javax.swing.JButton printButton;
    private javax.swing.JTextField studentIdText;
    private javax.swing.JTextField telephoneNoText;
    private javax.swing.JTextField universityNameText;
    private javax.swing.JButton verifyButton;
    private javax.swing.JTextField yearText;
    private javax.swing.JRadioButton yesRadioButton;
    // End of variables declaration//GEN-END:variables
}
