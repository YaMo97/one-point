/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package onepointverification;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;

/**
 *
 * @author lenovo
 */
public class HttpPost {

    public static URL url;
    public static HttpURLConnection httpURLConnection;

    public HttpPost() {
        url = null;
        httpURLConnection = null;
    }

    public static void sendRequest(String targetServlet, String data, String category) {

        try {

            URI uri = new URI("http", "null", "localhost", 7080, "/OnePointVerificationServer" + targetServlet, null, null);
//            URI uri = new URI(
//                "http", 
//                "localhost:7080", 
//                "/OnePointVerificationServer" 
//                + targetServlet,
//                null);
            URL url = uri.toURL();
            httpURLConnection = (HttpURLConnection) url.openConnection();

            //setting the properties of the connection
            httpURLConnection.setRequestMethod("POST");
            //httpURLConnection.setRequestProperty("Content-Type","text/plain");
            httpURLConnection.setRequestProperty("Content-Type", "application/json");
            httpURLConnection.setRequestProperty("Content-Length", ""
                    + Integer.toString(data.getBytes().length));
            httpURLConnection.setRequestProperty("Category", category);
            httpURLConnection.setUseCaches(false);
            httpURLConnection.setDoInput(true);
            httpURLConnection.setDoOutput(true);

            //writing to the server
            DataOutputStream dos = new DataOutputStream(httpURLConnection.getOutputStream());
            dos.writeBytes(data);
            dos.flush();
            dos.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static Reply<Integer,StringBuffer> receiveResponse() {
        int errCode;
        StringBuffer response;
        
        try {
            errCode = Integer.parseInt(httpURLConnection.getHeaderField("ErrCode"));

            //Creating input streams
            InputStream is = httpURLConnection.getInputStream();
            BufferedReader rd = new BufferedReader(new InputStreamReader(is));

            String line;
            response = new StringBuffer();

            //Reading from the stream
            while ((line = rd.readLine()) != null) {

                response.append(line);
            }

            rd.close();
            // System.out.println(response);
        } catch (Exception e) {
            System.out.println(e);
            errCode = -2;
            response = new StringBuffer("(HttpPost) Exception Caught: " + e);
        }

        Reply reply = new Reply(errCode, response);
        
        return reply;
    }
}
