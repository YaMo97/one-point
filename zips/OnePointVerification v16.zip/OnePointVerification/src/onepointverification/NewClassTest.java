/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package onepointverification;

 
import java.util.*;  
import javax.mail.*;  
import javax.mail.internet.*;  
import java.security.SecureRandom;
import java.math.BigInteger;
public class NewClassTest {  
 public String to=null;
	public NewClassTest(String to) { 
	 this.to=to;
	 

  System.out.println("in any");
 //String to="bhaveshkumar19856@gmail.com";//change accordingly  
  
  //Get the session object  
  Properties props = new Properties();  
  props.put("mail.smtp.host", "smtp.gmail.com");  
  props.put("mail.smtp.socketFactory.port", "25");  
  props.put("mail.smtp.socketFactory.class",  
            "javax.net.ssl.SSLSocketFactory");  
  props.put("mail.smtp.auth", "true");  
  props.put("mail.smtp.port", "25");  
   
  Session session = Session.getDefaultInstance(props,  
   new javax.mail.Authenticator() {  
   protected PasswordAuthentication getPasswordAuthentication() {  
   return new PasswordAuthentication("vivekmathur229@gmail.com","Vivek@229");//change accordingly  
   }  
  });  
   
  //compose message  
  try {  
   MimeMessage message = new MimeMessage(session);  
   message.setFrom(new InternetAddress("vivekmathur229@gmail.com"));//change accordingly  
   message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));  
   message.setSubject("Hello");  
   message.setText("password is "+nextSessionId());  
     
   //send message  
   Transport.send(message);  
  
   System.out.println("message sent successfully");  
   
  } catch (MessagingException e) {throw new RuntimeException(e);}  
   
 }  
	public String nextSessionId() {
		SecureRandom random1 = new SecureRandom();
	    return new BigInteger(64, random1).toString(32);
	  }
        
        
} 